{{/*
Expand the name of the chart.
*/}}
{{- define "baremetal-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "baremetal-operator.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "baremetal-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "baremetal-operator.labels" -}}
helm.sh/chart: {{ include "baremetal-operator.chart" . }}
{{ include "baremetal-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "baremetal-operator.selectorLabels" -}}
app.kubernetes.io/component: baremetal-operator
app.kubernetes.io/name: {{ include "baremetal-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Create the name of the service account to use
*/}}
{{- define "baremetal-operator.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "baremetal-operator.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{/*
Create the URL to use for connecting to the Ironic servers (e.g. API, cache)
*/}}
{{- define "baremetal-operator.ironicHttpHost" -}}
{{- $hostIP := include "metal3.hostIP" . -}}
{{- with .Values.global }}
{{- if .provisioningHostname }}
{{- .provisioningHostname }}
{{- else if regexMatch ".*:.*" $hostIP}}
{{- print "[" $hostIP "]" }}
{{- else }}
{{- $hostIP }}
{{- end }}
{{- end }}
{{- end }}
